# Contributors

Suraj Patil (https://github.com/thewhitetulip)

Jens Dieskau (https://github.com/jfreax)

Dima-1 (https://github.com/Dima-1)

AgiMaulana (https://github.com/AgiMaulana)

Richard Zhang (https://github.com/richardzhanguw)

See [pull requests](https://github.com/federicoiosue/Omni-Notes/pulls?q=is%3Aclosed) for all contributions.
